package dev.lelonio.square.ui

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import dev.lelonio.square.R

/**
 * What a long press on the app's icon offers: search, the music on the phone,
 * and the songs hearted on it.
 *
 * Published from the app each time it starts, so the labels follow the
 * language it is read in, and nothing here depends on the build's package name.
 * A tap arrives as an intent of its own; see MainActivity.takeLink.
 */
object AppShortcuts {

    const val ACTION = "dev.lelonio.square.action.SHORTCUT"
    const val EXTRA_TARGET = "target"

    const val SEARCH = "search"
    const val LOCAL_FILES = "local_files"
    const val LIKES = "likes"

    /** How a shortcut travels as a [LinkRequest]: this prefix, then the target. */
    const val URI_PREFIX = "square:shortcut:"

    fun publish(context: Context) {
        runCatching {
            val shortcuts = listOf(
                shortcut(context, SEARCH, R.string.search, R.drawable.ic_shortcut_search, 0),
                shortcut(context, LOCAL_FILES, R.string.local_files, R.drawable.ic_shortcut_folder, 1),
                shortcut(context, LIKES, R.string.liked_on_phone, R.drawable.ic_shortcut_heart, 2),
            )
            ShortcutManagerCompat.setDynamicShortcuts(context, shortcuts)
        }
    }

    private fun shortcut(context: Context, target: String, label: Int, icon: Int, rank: Int): ShortcutInfoCompat =
        ShortcutInfoCompat.Builder(context, "square_$target")
            .setShortLabel(context.getString(label))
            .setLongLabel(context.getString(label))
            .setIcon(IconCompat.createWithResource(context, icon))
            .setRank(rank)
            .setIntent(
                Intent(context, MainActivity::class.java)
                    .setAction(ACTION)
                    .putExtra(EXTRA_TARGET, target),
            )
            .build()
}
